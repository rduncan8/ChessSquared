import java.io.*;
import java.net.*;

public class Player 
{
    int playerNum;
    
    public Player(int playerNum)
    {
        this.playerNum = playerNum;
    }
}
