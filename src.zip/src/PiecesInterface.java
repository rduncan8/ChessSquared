
public interface PiecesInterface 
{   
}
