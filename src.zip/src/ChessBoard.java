import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.*;

public class ChessBoard extends Screen
{
    public int player;
    private int turn;
    private ChessBlock selectedBlock = null;
    private ChessBlock saveBlock = null;
    private final Color white = Color.WHITE;
    private final Color black = Color.BLACK;
    private final Color buttonColor1 = new Color(0, 130, 0);
    private final Color buttonColor2 = new Color(255, 255, 255);
    private ArrayList<ChessBlock> possibleMoves = new ArrayList<>();
    private ArrayList<ChessBlock> possibleCaptures = new ArrayList<>();
    private ArrayList<ChessBlock> fakePossibleMoves = new ArrayList<>();
    private ArrayList<ChessBlock> fakePossibleCaptures = new ArrayList<>();
    private ArrayList<ChessBlock> dangerousBlocksForWhite = new ArrayList<>();
    private ArrayList<ChessBlock> dangerousBlocksForBlack = new ArrayList<>();
    private ArrayList<ChessBlock> fakeDangerousBlocks = new ArrayList<>();
    private ArrayList<ChessBlock> fakeDangerousBlocksForBlack = new ArrayList<>();
    private ArrayList<ChessBlock> fakeDangerousBlocksForWhite = new ArrayList<>();
    private boolean gameOver = false;
    private boolean putInCheck = false;
    
    public PlayerWhite pWhite;
    public PlayerBlack pBlack;
    
    private final JFrame frame = createFrame("Chess");
    private final JPanel gui = new JPanel(new BorderLayout(3,3));
    private final JButton[][] chessBoardSquares = new JButton[8][8];
    private JPanel theChessBoard;
    private final JLabel message = new JLabel("Chess Champ is ready to play!");
    private static final String wCOLS = "ABCDEFGH";
    private static final String bCOLS = "HGFEDCBA";
    private static final String ROWS = "12345678";
    private int attackCounter = 1;
    
    public static ChessBlock[][] board = new ChessBlock[8][8];
    
    private Piece savePiece;
    private Piece saveCapturedPiece;
    
    private final Piece[] whitePawns = new Pawn[8];
    private final Piece[] whiteRooks = new Rook[10];
    private int whiteRookCounter = 2;
    private final Piece[] whiteKnights = new Knight[10];
    private int whiteKnightCounter = 2;
    private final Piece[] whiteBishops = new Bishop[10];
    private int whiteBishopCounter = 2;
    private Piece[] whiteQueen = new Queen[9];
    private int whiteQueenCounter= 1;
    private Piece whiteKing;
    private ArrayList<Piece> whitePieces = new ArrayList<>();
    
    private final Piece[] blackPawns = new Pawn[8];
    private final Piece[] blackRooks = new Rook[10];
    private int blackRookCounter = 2;
    private final Piece[] blackKnights = new Knight[10];
    private int blackKnightCounter = 2;
    private final Piece[] blackBishops = new Bishop[10];
    private int blackBishopCounter = 2;
    private Piece[] blackQueen = new Queen[9];
    private int blackQueenCounter = 1;
    private Piece blackKing;
    private ArrayList<Piece> blackPieces = new ArrayList<>();
    
    public ChessBoard(int player) 
    {
        this.player = player;
        turn = player;
        createGUI(player);
        frame.add(gui);
        frame.setVisible(true);
    }
    
    public final void createGUI(int player)
    {
        // set up the main GUI
        gui.setBorder(new EmptyBorder(5, 5, 5, 5));
        JToolBar tools = new JToolBar();
        tools.setFloatable(false);
        gui.add(tools, BorderLayout.PAGE_START);
        JButton newButton;
        JButton saveButton;
        JButton restoreButton;
        JButton resignButton;
        tools.add(newButton = new JButton("New")); // TODO - add functionality!
        newButton.addActionListener(new toolsListener());
        newButton.setActionCommand("New");
        tools.add(saveButton = new JButton("Save")); // TODO - add functionality!
        saveButton.addActionListener(new toolsListener());
        saveButton.setActionCommand("Save");
        tools.add(restoreButton = new JButton("Restore")); // TODO - add functionality!
        restoreButton.addActionListener(new toolsListener());
        restoreButton.setActionCommand("Restore");
        tools.addSeparator();
        tools.add(resignButton = new JButton("Resign")); // TODO - add functionality!
        resignButton.addActionListener(new toolsListener());
        resignButton.setActionCommand("Resign");
        tools.addSeparator();
        tools.add(message);
        
        theChessBoard = new JPanel(new GridLayout(0, 9));
        theChessBoard.setBorder(new LineBorder(Color.BLACK));
        gui.add(theChessBoard);
        
        setUpBoard(player);
        setUpPieces(player);
    }
    
    public void setUpBoard(int player)
    {    
        if(player == 1)
        {
            Insets buttonMargin = new Insets(0,0,0,0);
            for (int row = 7, actRow = 0; row >= 0; row--, actRow++)
            {
                for (int col = 0; col < chessBoardSquares[row].length; col++)
                {
                    JButton button = new JButton();
                    button.setMargin(buttonMargin);             
                    button.addActionListener(new MovePieceListener());
                    button.setActionCommand("" + Integer.toString(actRow) + 
                                                    Integer.toString(col));
                    // our chess pieces are 64x64 px in size, so we'll
                    // 'fill this in' using a transparent icon..
                    ImageIcon icon = new ImageIcon(
                            new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
                    button.setIcon(icon);
                    if ((col % 2 == 0 && row % 2 == 0) || (col % 2 == 1 && row % 2 == 1))
                    {
                        button.setBackground(Color.WHITE);
                    }
                    else
                    {
                        button.setBackground(Color.GREEN);
                    }
                    chessBoardSquares[col][row] = button;
                }
            }

            for (int row = 0, actRow = 8; row < 8; row++, actRow--)
            {
                for (int col = 0; col < 8; col++)
                {
                    switch (col)
                    {
                        case 0:
                            theChessBoard.add(new JLabel("" + (actRow),
                                    SwingConstants.CENTER));
                        default:
                            theChessBoard.add(chessBoardSquares[col][row]);
                    }
                }
            }

            theChessBoard.add(new JLabel(""));

            for (int letter = 0; letter < 8; letter++)
            {
                theChessBoard.add(
                    new JLabel(wCOLS.substring(letter, letter + 1),
                    SwingConstants.CENTER));
            }
            
        }
        else if(player == 2)
        {    
            Insets buttonMargin = new Insets(0,0,0,0);
            for (int row = 7, actRow = 0; row >= 0; row--, actRow++)
            {
                for (int col = 0; col < chessBoardSquares[row].length; col++)
                {
                    JButton button = new JButton();
                    button.setMargin(buttonMargin);             
                    button.addActionListener(new MovePieceListener());
                    button.setActionCommand("" + Integer.toString(actRow) + 
                                                    Integer.toString(col));
                    // our chess pieces are 64x64 px in size, so we'll
                    // 'fill this in' using a transparent icon..
                    ImageIcon icon = new ImageIcon(
                            new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
                    button.setIcon(icon);
                    if ((col % 2 == 0 && row % 2 == 0) || (col % 2 == 1 && row % 2 == 1))
                    {
                        button.setBackground(Color.WHITE);
                    }
                    else
                    {
                        button.setBackground(Color.GREEN);
                    }
                    chessBoardSquares[col][row] = button;
                }
            }

            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    switch (col)
                    {
                        case 0:
                            theChessBoard.add(new JLabel("" + (row+1),
                                    SwingConstants.CENTER));
                        default:
                            theChessBoard.add(chessBoardSquares[col][row]);
                    }
                }
            }

            theChessBoard.add(new JLabel(""));

            for (int letter = 0; letter < 8; letter++)
            {
                theChessBoard.add(
                    new JLabel(bCOLS.substring(letter, letter+1),
                    SwingConstants.CENTER));
            }
        }
    }
    
    public void setUpPieces(int player)
    {    
        createBlocks(player);
        createPieces();
        putPiecesOnBlocks();
    }
    
    public void createBlocks(int player)
    {
        if(player == 1){
            board[0][0] = new ChessBlock("A1", chessBoardSquares[0][7], 0, 0, buttonColor1);
            board[1][0] = new ChessBlock("B1", chessBoardSquares[1][7], 1, 0, buttonColor2);
            board[2][0] = new ChessBlock("C1", chessBoardSquares[2][7], 2, 0, buttonColor1);
            board[3][0] = new ChessBlock("D1", chessBoardSquares[3][7], 3, 0, buttonColor2);
            board[4][0] = new ChessBlock("E1", chessBoardSquares[4][7], 4, 0, buttonColor1);
            board[5][0] = new ChessBlock("F1", chessBoardSquares[5][7], 5, 0, buttonColor2);
            board[6][0] = new ChessBlock("G1", chessBoardSquares[6][7], 6, 0, buttonColor1);
            board[7][0] = new ChessBlock("H1", chessBoardSquares[7][7], 7, 0, buttonColor2);
            
            board[0][1] = new ChessBlock("A2", chessBoardSquares[0][6], 0, 1, buttonColor2);
            board[1][1] = new ChessBlock("B2", chessBoardSquares[1][6], 1, 1, buttonColor1);
            board[2][1] = new ChessBlock("C2", chessBoardSquares[2][6], 2, 1, buttonColor2);
            board[3][1] = new ChessBlock("D2", chessBoardSquares[3][6], 3, 1, buttonColor1);
            board[4][1] = new ChessBlock("E2", chessBoardSquares[4][6], 4, 1, buttonColor2);
            board[5][1] = new ChessBlock("F2", chessBoardSquares[5][6], 5, 1, buttonColor1);
            board[6][1] = new ChessBlock("G2", chessBoardSquares[6][6], 6, 1, buttonColor2);
            board[7][1] = new ChessBlock("H2", chessBoardSquares[7][6], 7, 1, buttonColor1);
            
            board[0][2] = new ChessBlock("A3", chessBoardSquares[0][5], 0, 2, buttonColor1);
            board[1][2] = new ChessBlock("B3", chessBoardSquares[1][5], 1, 2, buttonColor2);
            board[2][2] = new ChessBlock("C3", chessBoardSquares[2][5], 2, 2, buttonColor1);
            board[3][2] = new ChessBlock("D3", chessBoardSquares[3][5], 3, 2, buttonColor2);
            board[4][2] = new ChessBlock("E3", chessBoardSquares[4][5], 4, 2, buttonColor1);
            board[5][2] = new ChessBlock("F3", chessBoardSquares[5][5], 5, 2, buttonColor2);
            board[6][2] = new ChessBlock("G3", chessBoardSquares[6][5], 6, 2, buttonColor1);
            board[7][2] = new ChessBlock("H3", chessBoardSquares[7][5], 7, 2, buttonColor2);
            
            board[0][3] = new ChessBlock("A4", chessBoardSquares[0][4], 0, 3, buttonColor2);
            board[1][3] = new ChessBlock("B4", chessBoardSquares[1][4], 1, 3, buttonColor1);
            board[2][3] = new ChessBlock("C4", chessBoardSquares[2][4], 2, 3, buttonColor2);
            board[3][3] = new ChessBlock("D4", chessBoardSquares[3][4], 3, 3, buttonColor1);
            board[4][3] = new ChessBlock("E4", chessBoardSquares[4][4], 4, 3, buttonColor2);
            board[5][3] = new ChessBlock("F4", chessBoardSquares[5][4], 5, 3, buttonColor1);
            board[6][3] = new ChessBlock("G4", chessBoardSquares[6][4], 6, 3, buttonColor2);
            board[7][3] = new ChessBlock("H4", chessBoardSquares[7][4], 7, 3, buttonColor1);
            
            board[0][4] = new ChessBlock("A5", chessBoardSquares[0][3], 0, 4, buttonColor1);
            board[1][4] = new ChessBlock("B5", chessBoardSquares[1][3], 1, 4, buttonColor2);
            board[2][4] = new ChessBlock("C5", chessBoardSquares[2][3], 2, 4, buttonColor1);
            board[3][4] = new ChessBlock("D5", chessBoardSquares[3][3], 3, 4, buttonColor2);
            board[4][4] = new ChessBlock("E5", chessBoardSquares[4][3], 4, 4, buttonColor1);
            board[5][4] = new ChessBlock("F5", chessBoardSquares[5][3], 5, 4, buttonColor2);
            board[6][4] = new ChessBlock("G5", chessBoardSquares[6][3], 6, 4, buttonColor1);
            board[7][4] = new ChessBlock("H5", chessBoardSquares[7][3], 7, 4, buttonColor2);
            
            board[0][5] = new ChessBlock("A6", chessBoardSquares[0][2], 0, 5, buttonColor2);
            board[1][5] = new ChessBlock("B6", chessBoardSquares[1][2], 1, 5, buttonColor1);
            board[2][5] = new ChessBlock("C6", chessBoardSquares[2][2], 2, 5, buttonColor2);
            board[3][5] = new ChessBlock("D6", chessBoardSquares[3][2], 3, 5, buttonColor1);
            board[4][5] = new ChessBlock("E6", chessBoardSquares[4][2], 4, 5, buttonColor2);
            board[5][5] = new ChessBlock("F6", chessBoardSquares[5][2], 5, 5, buttonColor1);
            board[6][5] = new ChessBlock("G6", chessBoardSquares[6][2], 6, 5, buttonColor2);
            board[7][5] = new ChessBlock("H6", chessBoardSquares[7][2], 7, 5, buttonColor1);
            
            board[0][6] = new ChessBlock("A7", chessBoardSquares[0][1], 0, 6, buttonColor1);
            board[1][6] = new ChessBlock("B7", chessBoardSquares[1][1], 1, 6, buttonColor2);
            board[2][6] = new ChessBlock("C7", chessBoardSquares[2][1], 2, 6, buttonColor1);
            board[3][6] = new ChessBlock("D7", chessBoardSquares[3][1], 3, 6, buttonColor2);
            board[4][6] = new ChessBlock("E7", chessBoardSquares[4][1], 4, 6, buttonColor1);
            board[5][6] = new ChessBlock("F7", chessBoardSquares[5][1], 5, 6, buttonColor2);
            board[6][6] = new ChessBlock("G7", chessBoardSquares[6][1], 6, 6, buttonColor1);
            board[7][6] = new ChessBlock("H7", chessBoardSquares[7][1], 7, 6, buttonColor2);
                                                      
            board[0][7] = new ChessBlock("A8", chessBoardSquares[0][0], 0, 7, buttonColor2);
            board[1][7] = new ChessBlock("B8", chessBoardSquares[1][0], 1, 7, buttonColor1);
            board[2][7] = new ChessBlock("C8", chessBoardSquares[2][0], 2, 7, buttonColor2);
            board[3][7] = new ChessBlock("D8", chessBoardSquares[3][0], 3, 7, buttonColor1);
            board[4][7] = new ChessBlock("E8", chessBoardSquares[4][0], 4, 7, buttonColor2);
            board[5][7] = new ChessBlock("F8", chessBoardSquares[5][0], 5, 7, buttonColor1);
            board[6][7] = new ChessBlock("G8", chessBoardSquares[6][0], 6, 7, buttonColor2);
            board[7][7] = new ChessBlock("H8", chessBoardSquares[7][0], 7, 7, buttonColor1);
        }
        else if(player == 2)
        {    
            board[0][0] = new ChessBlock("A1", chessBoardSquares[7][0], 0, 0, buttonColor1);
            board[1][0] = new ChessBlock("B1", chessBoardSquares[6][0], 1, 0, buttonColor2);
            board[2][0] = new ChessBlock("C1", chessBoardSquares[5][0], 2, 0, buttonColor1);
            board[3][0] = new ChessBlock("D1", chessBoardSquares[4][0], 3, 0, buttonColor2);
            board[4][0] = new ChessBlock("E1", chessBoardSquares[3][0], 4, 0, buttonColor1);
            board[5][0] = new ChessBlock("F1", chessBoardSquares[2][0], 5, 0, buttonColor2);
            board[6][0] = new ChessBlock("G1", chessBoardSquares[1][0], 6, 0, buttonColor1);
            board[7][0] = new ChessBlock("H1", chessBoardSquares[0][0], 7, 0, buttonColor2);
            
            board[0][1] = new ChessBlock("A2", chessBoardSquares[7][1], 0, 1, buttonColor2);
            board[1][1] = new ChessBlock("B2", chessBoardSquares[6][1], 1, 1, buttonColor1);
            board[2][1] = new ChessBlock("C2", chessBoardSquares[5][1], 2, 1, buttonColor2);
            board[3][1] = new ChessBlock("D2", chessBoardSquares[4][1], 3, 1, buttonColor1);
            board[4][1] = new ChessBlock("E2", chessBoardSquares[3][1], 4, 1, buttonColor2);
            board[5][1] = new ChessBlock("F2", chessBoardSquares[2][1], 5, 1, buttonColor1);
            board[6][1] = new ChessBlock("G2", chessBoardSquares[1][1], 6, 1, buttonColor2);
            board[7][1] = new ChessBlock("H2", chessBoardSquares[0][1], 7, 1, buttonColor1);
            
            board[0][2] = new ChessBlock("A3", chessBoardSquares[7][2], 0, 2, buttonColor1);
            board[1][2] = new ChessBlock("B3", chessBoardSquares[6][2], 1, 2, buttonColor2);
            board[2][2] = new ChessBlock("C3", chessBoardSquares[5][2], 2, 2, buttonColor1);
            board[3][2] = new ChessBlock("D3", chessBoardSquares[4][2], 3, 2, buttonColor2);
            board[4][2] = new ChessBlock("E3", chessBoardSquares[3][2], 4, 2, buttonColor1);
            board[5][2] = new ChessBlock("F3", chessBoardSquares[2][2], 5, 2, buttonColor2);
            board[6][2] = new ChessBlock("G3", chessBoardSquares[1][2], 6, 2, buttonColor1);
            board[7][2] = new ChessBlock("H3", chessBoardSquares[0][2], 7, 2, buttonColor2);
            
            board[0][3] = new ChessBlock("A4", chessBoardSquares[7][3], 0, 3, buttonColor2);
            board[1][3] = new ChessBlock("B4", chessBoardSquares[6][3], 1, 3, buttonColor1);
            board[2][3] = new ChessBlock("C4", chessBoardSquares[5][3], 2, 3, buttonColor2);
            board[3][3] = new ChessBlock("D4", chessBoardSquares[4][3], 3, 3, buttonColor1);
            board[4][3] = new ChessBlock("E4", chessBoardSquares[3][3], 4, 3, buttonColor2);
            board[5][3] = new ChessBlock("F4", chessBoardSquares[2][3], 5, 3, buttonColor1);
            board[6][3] = new ChessBlock("G4", chessBoardSquares[1][3], 6, 3, buttonColor2);
            board[7][3] = new ChessBlock("H4", chessBoardSquares[0][3], 7, 3, buttonColor1);
            
            board[0][4] = new ChessBlock("A5", chessBoardSquares[7][4], 0, 4, buttonColor1);
            board[1][4] = new ChessBlock("B5", chessBoardSquares[6][4], 1, 4, buttonColor2);
            board[2][4] = new ChessBlock("C5", chessBoardSquares[5][4], 2, 4, buttonColor1);
            board[3][4] = new ChessBlock("D5", chessBoardSquares[4][4], 3, 4, buttonColor2);
            board[4][4] = new ChessBlock("E5", chessBoardSquares[3][4], 4, 4, buttonColor1);
            board[5][4] = new ChessBlock("F5", chessBoardSquares[2][4], 5, 4, buttonColor2);
            board[6][4] = new ChessBlock("G5", chessBoardSquares[1][4], 6, 4, buttonColor1);
            board[7][4] = new ChessBlock("H5", chessBoardSquares[0][4], 7, 4, buttonColor2);
            
            board[0][5] = new ChessBlock("A6", chessBoardSquares[7][5], 0, 5, buttonColor2);
            board[1][5] = new ChessBlock("B6", chessBoardSquares[6][5], 1, 5, buttonColor1);
            board[2][5] = new ChessBlock("C6", chessBoardSquares[5][5], 2, 5, buttonColor2);
            board[3][5] = new ChessBlock("D6", chessBoardSquares[4][5], 3, 5, buttonColor1);
            board[4][5] = new ChessBlock("E6", chessBoardSquares[3][5], 4, 5, buttonColor2);
            board[5][5] = new ChessBlock("F6", chessBoardSquares[2][5], 5, 5, buttonColor1);
            board[6][5] = new ChessBlock("G6", chessBoardSquares[1][5], 6, 5, buttonColor2);
            board[7][5] = new ChessBlock("H6", chessBoardSquares[0][5], 7, 5, buttonColor1);

            board[0][6] = new ChessBlock("A7", chessBoardSquares[7][6], 0, 6, buttonColor1);
            board[1][6] = new ChessBlock("B7", chessBoardSquares[6][6], 1, 6, buttonColor2);
            board[2][6] = new ChessBlock("C7", chessBoardSquares[5][6], 2, 6, buttonColor1);
            board[3][6] = new ChessBlock("D7", chessBoardSquares[4][6], 3, 6, buttonColor2);
            board[4][6] = new ChessBlock("E7", chessBoardSquares[3][6], 4, 6, buttonColor1);
            board[5][6] = new ChessBlock("F7", chessBoardSquares[2][6], 5, 6, buttonColor2);
            board[6][6] = new ChessBlock("G7", chessBoardSquares[1][6], 6, 6, buttonColor1);
            board[7][6] = new ChessBlock("H7", chessBoardSquares[0][6], 7, 6, buttonColor2);
            
            board[0][7] = new ChessBlock("A8", chessBoardSquares[7][7], 0, 7, buttonColor2);
            board[1][7] = new ChessBlock("B8", chessBoardSquares[6][7], 1, 7, buttonColor1);
            board[2][7] = new ChessBlock("C8", chessBoardSquares[5][7], 2, 7, buttonColor2);
            board[3][7] = new ChessBlock("D8", chessBoardSquares[4][7], 3, 7, buttonColor1);
            board[4][7] = new ChessBlock("E8", chessBoardSquares[3][7], 4, 7, buttonColor2);
            board[5][7] = new ChessBlock("F8", chessBoardSquares[2][7], 5, 7, buttonColor1);
            board[6][7] = new ChessBlock("G8", chessBoardSquares[1][7], 6, 7, buttonColor2);
            board[7][7] = new ChessBlock("H8", chessBoardSquares[0][7], 7, 7, buttonColor1);
        }
    }
    
    public void createPieces()
    {
        whitePawns[0] = new Pawn(white, board[0][1], putInCheck);
        whitePawns[1] = new Pawn(white, board[1][1], putInCheck);
        whitePawns[2] = new Pawn(white, board[2][1], putInCheck);
        whitePawns[3] = new Pawn(white, board[3][1], putInCheck);
        whitePawns[4] = new Pawn(white, board[4][1], putInCheck);
        whitePawns[5] = new Pawn(white, board[5][1], putInCheck);
        whitePawns[6] = new Pawn(white, board[6][1], putInCheck);
        whitePawns[7] = new Pawn(white, board[7][1], putInCheck);
        whiteRooks[0] = new Rook(white, board[0][0], putInCheck); 
        whiteRooks[1] = new Rook(white, board[7][0], putInCheck);
        whiteKnights[0] = new Knight(white, board[1][0], putInCheck); 
        whiteKnights[1] = new Knight(white, board[6][0], putInCheck);
        whiteBishops[0] = new Bishop(white, board[2][0], putInCheck); 
        whiteBishops[1] = new Bishop(white, board[5][0], putInCheck);
        whiteKing = new King(white, board[4][0], putInCheck);
        whiteQueen[0] = new Queen(white, board[3][0], putInCheck);
        
        whitePieces.add(whitePawns[0]);
        whitePieces.add(whitePawns[1]);
        whitePieces.add(whitePawns[2]);
        whitePieces.add(whitePawns[3]);
        whitePieces.add(whitePawns[4]);
        whitePieces.add(whitePawns[5]);
        whitePieces.add(whitePawns[6]);
        whitePieces.add(whitePawns[7]);
        whitePieces.add(whiteRooks[0]);
        whitePieces.add(whiteRooks[1]);
        whitePieces.add(whiteKnights[0]);
        whitePieces.add(whiteKnights[1]);
        whitePieces.add(whiteBishops[0]);
        whitePieces.add(whiteBishops[1]);
        whitePieces.add(whiteQueen[0]);
        whitePieces.add(whiteKing);
        
        blackPawns[0] = new Pawn(black, board[0][6], putInCheck);
        blackPawns[1] = new Pawn(black, board[1][6], putInCheck);
        blackPawns[2] = new Pawn(black, board[2][6], putInCheck);
        blackPawns[3] = new Pawn(black, board[3][6], putInCheck);
        blackPawns[4] = new Pawn(black, board[4][6], putInCheck);
        blackPawns[5] = new Pawn(black, board[5][6], putInCheck);
        blackPawns[6] = new Pawn(black, board[6][6], putInCheck);
        blackPawns[7] = new Pawn(black, board[7][6], putInCheck);
        blackRooks[0] = new Rook(black, board[0][7], putInCheck); 
        blackRooks[1] = new Rook(black, board[7][7], putInCheck);
        blackKnights[0] = new Knight(black, board[1][7], putInCheck); 
        blackKnights[1] = new Knight(black, board[6][7], putInCheck);
        blackBishops[0] = new Bishop(black, board[2][7], putInCheck); 
        blackBishops[1] = new Bishop(black, board[5][7], putInCheck);
        blackKing = new King(black, board[4][7], putInCheck);
        blackQueen[0] = new Queen(black, board[3][7], putInCheck);
        
        blackPieces.add(blackPawns[0]);
        blackPieces.add(blackPawns[1]);
        blackPieces.add(blackPawns[2]);
        blackPieces.add(blackPawns[3]);
        blackPieces.add(blackPawns[4]);
        blackPieces.add(blackPawns[5]);
        blackPieces.add(blackPawns[6]);
        blackPieces.add(blackPawns[7]);
        blackPieces.add(blackRooks[0]);
        blackPieces.add(blackRooks[1]);
        blackPieces.add(blackKnights[0]);
        blackPieces.add(blackKnights[1]);
        blackPieces.add(blackBishops[0]);
        blackPieces.add(blackBishops[1]);
        blackPieces.add(blackQueen[0]);
        blackPieces.add(blackKing);
    }
    
    public void putPiecesOnBlocks()
    {
        board[0][0].setPiece(whiteRooks[0]);
        board[1][0].setPiece(whiteKnights[0]);
        board[2][0].setPiece(whiteBishops[0]);
        board[3][0].setPiece(whiteQueen[0]);
        board[4][0].setPiece(whiteKing);
        board[5][0].setPiece(whiteBishops[1]);
        board[6][0].setPiece(whiteKnights[1]);
        board[7][0].setPiece(whiteRooks[1]);
        
        board[0][1].setPiece(whitePawns[0]);
        board[1][1].setPiece(whitePawns[1]);
        board[2][1].setPiece(whitePawns[2]);
        board[3][1].setPiece(whitePawns[3]);
        board[4][1].setPiece(whitePawns[4]);
        board[5][1].setPiece(whitePawns[5]);
        board[6][1].setPiece(whitePawns[6]);
        board[7][1].setPiece(whitePawns[7]);
        
        board[0][6].setPiece(blackPawns[0]);
        board[1][6].setPiece(blackPawns[1]);
        board[2][6].setPiece(blackPawns[2]);
        board[3][6].setPiece(blackPawns[3]);
        board[4][6].setPiece(blackPawns[4]);
        board[5][6].setPiece(blackPawns[5]);
        board[6][6].setPiece(blackPawns[6]);
        board[7][6].setPiece(blackPawns[7]);
        
        board[0][7].setPiece(blackRooks[0]);
        board[1][7].setPiece(blackKnights[0]);
        board[2][7].setPiece(blackBishops[0]);
        board[3][7].setPiece(blackQueen[0]);
        board[4][7].setPiece(blackKing);
        board[5][7].setPiece(blackBishops[1]);
        board[6][7].setPiece(blackKnights[1]);
        board[7][7].setPiece(blackRooks[1]);
    }
    
    public class toolsListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e){
            //new save restore resign
            if("new".equals(e.getActionCommand())){
                Game.newGame();
                frame.setVisible(false);
            }else if("save".equals(e.getActionCommand())){
                
            }else if("restore".equals(e.getActionCommand())){
                
            }else if("resign".equals(e.getActionCommand())){
                
            }
        }
    }
    
    private boolean isPieceSelected()
    {
        return selectedBlock != null;
    }
    
    private void blockClicked(ChessBlock chessBlock)
    {
        if (!gameOver)
        {
            if (chessBlock.hasPiece())
            {
                if (isPieceSelected() && chessBlock != selectedBlock && possibleCaptures.contains(chessBlock))
                {
                    capturePiece(chessBlock);
                }
                else if ((turn == 1 && chessBlock.getPiece().color == Color.WHITE) || (turn == 2 && chessBlock.getPiece().color == Color.BLACK))
                {
                    selectBlock(chessBlock);
                }
            }
            else
            {
                if (isPieceSelected())
                {
                    if (chessBlock != selectedBlock)
                    {
                        if (possibleMoves.contains(chessBlock))
                        {
                            moveToBlock(chessBlock);
                        }
                    }
                }
            }
        }
    }
    
    private void selectBlock(ChessBlock chessBlock)
    {
        if (selectedBlock != null)
        {
            selectedBlock.setSelectedPieceButtonColor(false);
        }
        selectedBlock = chessBlock;
        selectedBlock.setSelectedPieceButtonColor(true);
        getPossibleMovesAndCaptures();
    }
    
    private void moveToBlock(ChessBlock chessBlock)
    {
        selectedBlock.getPiece().fakeMove(chessBlock);
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        if(turn == 1)
        {
            for (int i = 0; i < blackPieces.size(); i++)
            {
                dangerousBlocks = findDangerousBlocks(blackPieces.get(i));
                if (!dangerousBlocks.contains(whiteKing.currentPosition))
                {
                    
                    if (chessBlock.getPiece().pieceName == "king" && chessBlock.getPiece().hasMoved == false)
                    {
                        if (chessBlock.y == 0)
                        {
                            if (selectedBlock.x+2 == chessBlock.x && board[6][0].getPiece().hasMoved == false)
                            {
                                board[7][0].getPiece().move(board[5][0]);
                            }
                            else if (selectedBlock.x-2 == chessBlock.x && board[0][0].getPiece().hasMoved == false)
                            {
                                board[0][0].getPiece().move(board[3][0]);
                            }
                        }
                    }
                    
                    chessBlock.getPiece().revert(selectedBlock);
                    selectedBlock.getPiece().move(chessBlock);
                    dangerousBlocks.clear();
                    clearPossibleMovesAndCaptures();
                    selectedBlock.setSelectedPieceButtonColor(false);
                    
                    //promotion check.
                    for (int j = 0; j < 8; j++)
                    {
                        if (chessBlock.getPiece().isPawn && chessBlock.x == j && chessBlock.y == 7)
                        {
                            promote(chessBlock);
                        }
                    }
                    
                    //Supposed to check if any pieces after you move a piece causes 
                    //this or any other pieces this player has and check to see if any
                    //of the threatened squares it has the black king and switch
                    //the "putInCheck" value to true to signify that this piece is the one to
                    //put their king in check.
                    
                    //WARNING: THIS FREEZES THE GAME!
                    //to escape, end task using task manager.
                    
//                    for (int j = 0; j < whitePieces.size(); i++)
//                    {
//                        dangerousBlocks = findDangerousBlocks(whitePieces.get(j));
//                        if (dangerousBlocks.contains(blackKing.currentPosition))
//                        {
//                            whitePieces.get(j).switchPutInCheck();
//                            dangerousBlocks.clear();
//                        }
//                        dangerousBlocks.clear();
//                    }
                    
                    //This supposed to do the same as the code above, but checks to
                    //see if the move you made blocks a piece and if it does, then
                    //switches the "putInCheck" value to false.
                    
                    //WARNING: THIS FREEZES THE GAME!
                    //to escape, end task using task manager.
                    
//                    for (int j = 0; j < blackPieces.size(); i++)
//                    {
//                        dangerousBlocks = findDangerousBlocks(blackPieces.get(j));
//                        if (blackPieces.get(j).putInCheck == true)
//                        {
//                            if (!dangerousBlocks.contains(whiteKing.currentPosition)){
//                                blackPieces.get(j).switchPutInCheck();
//                                dangerousBlocks.clear();
//                            }
//                        }
//                        dangerousBlocks.clear();
//                    }
                    
                }
                else
                {
                    chessBlock.getPiece().revert(selectedBlock);
                    if (chessBlock.hasPiece())
                    {
                        System.out.println("This block has a piece in it already by: " + chessBlock.getPiece().pieceName);
                    }
                    if (fakeDangerousBlocksForWhite.contains(chessBlock))
                    {
                        System.out.println("This block is threatened...");
                        for (int j = 0; j < blackPieces.size(); j++)
                        {
                            if (findDangerousBlocks(blackPieces.get(j)).contains(chessBlock))
                            {
                                System.out.println("This block is threatened by: " + blackPieces.get(j).pieceName);
                            }
                        }
                    }
                    //chessBlock.getPiece().revert(selectedBlock);
                    dangerousBlocksForWhite.clear();
                    clearPossibleMovesAndCaptures();
                    selectedBlock.setSelectedPieceButtonColor(false);
                }
            }
            dangerousBlocks.clear();
            switchTurn();
        }
        else
        {
            for (int i = 0; i < whitePieces.size(); i++)
            {
                dangerousBlocks = findDangerousBlocks(whitePieces.get(i));
                if (!dangerousBlocks.contains(blackKing.currentPosition))
                {
                    
                    if (chessBlock.getPiece().pieceName == "king" && chessBlock.getPiece().hasMoved == false)
                    {
                        if (chessBlock.y == 0)
                        {
                            if (selectedBlock.x+2 == chessBlock.x && board[6][0].getPiece().hasMoved == false)
                            {
                                board[7][0].getPiece().move(board[5][0]);
                            }
                            else if (selectedBlock.x-2 == chessBlock.x && board[0][0].getPiece().hasMoved == false)
                            {
                                board[0][0].getPiece().move(board[3][0]);
                            }
                        }
                    }
                    
                    chessBlock.getPiece().revert(selectedBlock);
                    chessBlock.setPiece(null);
                    selectedBlock.getPiece().move(chessBlock);
                    dangerousBlocksForBlack.clear();
                    clearPossibleMovesAndCaptures();
                    selectedBlock.setSelectedPieceButtonColor(false);
                    for (int j = 0; j < 8; j++)
                    {
                        if (chessBlock.getPiece().isPawn && chessBlock.x == j && chessBlock.y == 0)
                        {
                            promote(chessBlock);
                        }
                    }
                    
                    //WARNING: THIS BREAKS THE GAME
                    
                    //To escape, end process on Task Manager
                    
//                    for (int j = 0; j < blackPieces.size(); i++)
//                    {
//                        if (whitePieces.get(j).putInCheck)
//                        {
//                            whitePieces.get(j).switchPutInCheck();
//                        }
//                    }
                    
                }
                else
                {
                    chessBlock.getPiece().revert(selectedBlock);
                    if (chessBlock.hasPiece())
                    {
                        System.out.println("This block has a piece in it already by: " + chessBlock.getPiece().pieceName);
                    }
                    if (fakeDangerousBlocksForBlack.contains(chessBlock))
                    {
                        System.out.println("This block is threatened...");
                        for (int j = 0; j < whitePieces.size(); j++)
                        {
                            if (findDangerousBlocks(whitePieces.get(j)).contains(chessBlock))
                            {
                                System.out.println("This block is threatened by: " + blackPieces.get(j).pieceName);
                            }
                        }
                    }
                    //chessBlock.getPiece().revert(selectedBlock);
                    dangerousBlocksForWhite.clear();
                    clearPossibleMovesAndCaptures();
                    selectedBlock.setSelectedPieceButtonColor(false);
                }
            }
            dangerousBlocks.clear();
            switchTurn();
        }
        
        checkInCheck(chessBlock);
        
        
        selectedBlock = null;
    }
    
    //promotion logic
    private void promote(ChessBlock chessBlock)
    {
        Object[] options = {"Queen", "Rook", "Knight", "Bishop"};
        
        int dialogResult = JOptionPane.showOptionDialog(null,
                "Please select a piece you would like to promote " + chessBlock.getPiece().pieceName + " at " + board[chessBlock.x][chessBlock.y].getBlockDescription() + " to.",
                "Pick a piece.", JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.YES_NO_CANCEL_OPTION,
                null, options, options[0]);
        
        for (int i = 0; i < 8; i++)
        {
            if (turn == 1)
            {
                if (board[i][7].getPiece().isPawn)
                {
                    if (dialogResult == 0)
                    {
                        whitePieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        whiteQueen[whiteQueenCounter] = new Queen(white, board[chessBlock.x][chessBlock.y], putInCheck);
                        whitePieces.add(whiteQueen[whiteQueenCounter]);
                        chessBlock.setPiece(whiteQueen[whiteQueenCounter]);
                        checkInCheck(chessBlock);
                        whiteQueenCounter++;
                        break;
                    }
                    else if (dialogResult == 1)
                    {
                        whitePieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        whiteRooks[whiteRookCounter] = new Rook(white, board[chessBlock.x][chessBlock.y], putInCheck);
                        whitePieces.add(whiteRooks[whiteRookCounter]);
                        chessBlock.setPiece(whiteRooks[whiteRookCounter]);
                        checkInCheck(chessBlock);
                        whiteRookCounter++;
                        break;
                    }
                    else if (dialogResult == 2)
                    {
                        whitePieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        whiteKnights[whiteKnightCounter] = new Knight(white, board[chessBlock.x][chessBlock.y], putInCheck);
                        whitePieces.add(whiteKnights[whiteKnightCounter]);
                        chessBlock.setPiece(whiteKnights[whiteKnightCounter]);
                        checkInCheck(chessBlock);
                        whiteKnightCounter++;
                        break;
                    }
                    else if (dialogResult == 3)
                    {
                        whitePieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        whiteBishops[whiteBishopCounter] = new Bishop(white, board[chessBlock.x][chessBlock.y], putInCheck);
                        whitePieces.add(whiteBishops[whiteBishopCounter]);
                        chessBlock.setPiece(whiteBishops[whiteBishopCounter]);
                        checkInCheck(chessBlock);
                        whiteBishopCounter++;
                        break;
                    }
                }
                else if (board[i][0].getPiece().isPawn)
                {
                    if (dialogResult == 0)
                    {
                        blackPieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        blackQueen[blackQueenCounter] = new Queen(black, board[chessBlock.x][chessBlock.y], putInCheck);
                        blackPieces.add(blackQueen[blackQueenCounter]);
                        chessBlock.setPiece(blackQueen[blackQueenCounter]);
                        checkInCheck(chessBlock);
                        blackQueenCounter++;
                        break;
                    }
                    else if (dialogResult == 1)
                    {
                        blackPieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        blackRooks[blackRookCounter] = new Rook(black, board[chessBlock.x][chessBlock.y], putInCheck);
                        blackPieces.add(blackRooks[blackRookCounter]);
                        chessBlock.setPiece(blackRooks[blackRookCounter]);
                        checkInCheck(chessBlock);
                        blackRookCounter++;
                        break;
                    }
                    else if (dialogResult == 2)
                    {
                        blackPieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        blackKnights[blackKnightCounter] = new Knight(black, board[chessBlock.x][chessBlock.y], putInCheck);
                        blackPieces.add(blackKnights[blackKnightCounter]);
                        chessBlock.setPiece(blackKnights[blackKnightCounter]);
                        checkInCheck(chessBlock);
                        blackKnightCounter++;
                        break;
                    }
                    else if (dialogResult == 3)
                    {
                        blackPieces.remove(chessBlock.getPiece());
                        chessBlock.setPiece(null);
                        blackBishops[blackBishopCounter] = new Bishop(black, board[chessBlock.x][chessBlock.y], putInCheck);
                        blackPieces.add(blackBishops[blackBishopCounter]);
                        chessBlock.setPiece(blackBishops[blackBishopCounter]);
                        checkInCheck(chessBlock);
                        blackBishopCounter++;
                        break;
                    }
                }
            }
        }
    }
    
    private boolean checkInCheck(ChessBlock chessBlock)
    {
        if (turn == 1)
        {
            findFakeDangerousBlocksForWhite();
        }
        else
        {
            findFakeDangerousBlocksForBlack();
        }
        
        if(fakeDangerousBlocksForWhite.contains(whiteKing.currentPosition)  || fakeDangerousBlocksForBlack.contains(blackKing.currentPosition))
        {
            
            if ("pawn".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            else if ("rook".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            else if ("knight".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            else if ("bishop".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            else if ("queen".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            else if ("king".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().switchPutInCheck();
            }
            
            fakeDangerousBlocks = null;
        }
        
        return chessBlock.getPiece().putInCheck;
    }
    
    private void capturePiece(ChessBlock chessBlock)
    {
        saveCapturedPiece = chessBlock.getPiece();
        chessBlock.setPiece(null);
        chessBlock = selectedBlock;
        savePiece = selectedBlock.getPiece();
        chessBlock.getPiece().setCurrentPosition(chessBlock);
        saveBlock = selectedBlock;
        selectedBlock = null;
        if(turn == 1)
        {
            findFakeDangerousBlocksForBlack();
            
            if (!fakeDangerousBlocks.contains(whiteKing.currentPosition))
            {
                
                fakeDangerousBlocks.clear();
                chessBlock = null;
                saveBlock.getPiece().move(chessBlock);
                clearPossibleMovesAndCaptures();
                saveBlock = null;
                savePiece = null;
                saveCapturedPiece = null;
                selectedBlock.setSelectedPieceButtonColor(false);
            }
            else if (fakeDangerousBlocks.contains(whiteKing.currentPosition))
            {
                chessBlock.setPiece(saveCapturedPiece);
                selectedBlock = saveBlock;
                selectedBlock.getPiece().setCurrentPosition(savePiece.currentPosition);
                saveBlock = null;
                saveCapturedPiece = null;
                savePiece = null;
            }
        }
        else
        {
            findFakeDangerousBlocksForBlack();
            
            if (!fakeDangerousBlocks.contains(blackKing.currentPosition))
            {
                chessBlock = null;
                saveBlock.getPiece().move(chessBlock);
                fakeDangerousBlocks.clear();
                clearPossibleMovesAndCaptures();
                saveBlock = null;
                savePiece = null;
                saveCapturedPiece = null;
                selectedBlock.setSelectedPieceButtonColor(false);
            }
            else
            {
                chessBlock.setPiece(saveCapturedPiece);
                selectedBlock = saveBlock;
                selectedBlock.getPiece().setCurrentPosition(savePiece.currentPosition);
                saveBlock = null;
                saveCapturedPiece = null;
                savePiece = null;
            }
        }
        
        if (turn == 1)
        {
            findFakeDangerousBlocksForWhite();
        }
        else
        {
            findFakeDangerousBlocksForBlack();
        }
        
        if(fakeDangerousBlocks.contains(blackKing.currentPosition)  || fakeDangerousBlocks.contains(whiteKing.currentPosition))
        {
            if ("pawn".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
            else if ("rook".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
            else if ("knight".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
            else if ("bishop".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
            else if ("queen".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
            else if ("king".equals(chessBlock.getPiece().pieceName))
            {
                chessBlock.getPiece().putInCheck = true;
            }
        }
        
        fakeDangerousBlocks = null;
        selectedBlock = null;
        switchTurn();
        
        
        chessBlock.setPiece(null);
        clearPossibleMovesAndCaptures();
        selectedBlock.getPiece().move(chessBlock);
        selectedBlock.setSelectedPieceButtonColor(false);
        selectedBlock = null;
        switchTurn();
    }
    
    private void switchTurn()
    {
        if (turn == 1)
        {
            turn = 2;
            for (int i = 0; i < 8; i++)
            {
                if (board[i][4].hasPiece())
                {
                    if (board[i][4].getPiece().isPawn && board[i][4].getPiece().color == Color.BLACK && board[i][4].getPiece().enPassantCounter == 0)
                    {
                        board[i][4].getPiece().decreaseEnPassantCounter();
                        System.out.println("En Passant Counter = " + board[i][4].getPiece().enPassantCounter + " at " + board[i][4].getBlockDescription());
                    }
                }
            }
            findDangerousBlocksForBlack();
            System.out.println("found dangerous for black");
            if (dangerousBlocksForBlack.contains(blackKing.currentPosition))
            {
                System.out.println("black in check");
                selectBlock(blackKing.currentPosition);
                checkForWinner();
            }
        }
        else
        {
            turn = 1;
            for (int i = 0; i < 8; i++)
            {
                if (board[i][3].hasPiece())
                {
                    if (board[i][3].getPiece().isPawn && board[i][3].getPiece().color == Color.WHITE && board[i][3].getPiece().enPassantCounter == 0)
                    {
                        board[i][3].getPiece().decreaseEnPassantCounter();
                        System.out.println("En Passant Counter = " + board[i][3].getPiece().enPassantCounter + " at " + board[i][3].getBlockDescription());
                    }
                }
            }
            findDangerousBlocksForWhite();
            System.out.println("found dangerous for white");
            if (dangerousBlocksForWhite.contains(whiteKing.currentPosition))
            {
                System.out.println("White in check");
                selectBlock(whiteKing.currentPosition);
                checkForWinner();
            }        
        }
    }
    
    private void checkForWinner()
    {
        /*if (turn == 1)
        {
            for (int i = 0; i <blackPieces.size(); i++)
            {
                if (blackPieces.get(i).putInCheck)
                {
                    fakeDangerousBlocksForWhite = checkDirection(blackPieces.get(i));
                    for (int j = 0; j < whitePieces.size(); j++)
                    {
                        fakeDangerousBlocksForBlack = findDangerousBlocks(whitePieces.get(j));
                        if (fakeDangerousBlocksForWhite.contains(fakeDangerousBlocksForBlack) && fakeDangerousBlocksForWhite.contains(blackPieces.get(i)))
                        {
                            fakeDangerousBlocks = fakeDangerousBlocksForWhite;
                            fakeDangerousBlocksForBlack.clear();
                            fakeDangerousBlocksForWhite.clear();
                        }
                    }
                }
            }
        }
        else
        {
            for (int i = 0; i <whitePieces.size(); i++)
            {
                if (whitePieces.get(i).putInCheck)
                {
                    fakeDangerousBlocksForBlack = checkDirection(whitePieces.get(i));
                    for (int j = 0; j < blackPieces.size(); j++)
                    {
                        fakeDangerousBlocksForWhite = findDangerousBlocks(blackPieces.get(j));
                        if (fakeDangerousBlocksForBlack.contains(fakeDangerousBlocksForWhite) && fakeDangerousBlocksForBlack.contains(whitePieces.get(i)))
                        {
                            fakeDangerousBlocks = fakeDangerousBlocksForBlack;
                            fakeDangerousBlocksForBlack.clear();
                            fakeDangerousBlocksForWhite.clear();
                        }
                    }
                }
            }
        }
        if (fakeDangerousBlocks.isEmpty())
        {
            gameOver = true;
            for (int y = 0; y < 8; y++)
            {
                for (int x = 0; x < 8; x++)
                {
                    board[x][y].setWinnerButtonColor(gameOver, selectedBlock.getPiece().color);
                }
            }
        }
        fakeDangerousBlocks.clear();*/
    }
    
    private void findDangerousBlocksForWhite()
    {
        dangerousBlocksForBlack.forEach(block -> block.setDangerousButtonColor(false));
        dangerousBlocksForWhite.forEach(block -> block.setDangerousButtonColor(false));
        dangerousBlocksForWhite.clear();
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        for (int i = 0; i < blackPieces.size(); i++)
        {
            dangerousBlocks = findDangerousBlocks(blackPieces.get(i));
            dangerousBlocks.forEach(block -> { dangerousBlocksForWhite.add(block); });
            /*for (int j = 0; j < dangerousBlocks.size(); j++)
            {
                System.out.println(dangerousBlocks.get(j).getBlockDescription());
            }*/
            dangerousBlocks.clear();
        }
        // setting this to true or false determines if dangerous squares are highlighted
        dangerousBlocksForWhite.forEach(block -> block.setDangerousButtonColor(true));
    }
    
    private void findFakeDangerousBlocksForWhite()
    {
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();

        fakeDangerousBlocksForWhite.clear();
        for (int i = 0; i < blackPieces.size(); i++)
        {
            dangerousBlocks = findDangerousBlocks(blackPieces.get(i));
            dangerousBlocks.forEach(block -> fakeDangerousBlocksForWhite.add(block));
            dangerousBlocks.clear();
        }
    }
    
    private void findDangerousBlocksForBlack()
    {
        dangerousBlocksForBlack.forEach(block -> block.setDangerousButtonColor(false));
        dangerousBlocksForWhite.forEach(block -> block.setDangerousButtonColor(false));
        dangerousBlocksForBlack.clear();
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        for (int i = 0; i < whitePieces.size(); i++)
        {
            dangerousBlocks = findDangerousBlocks(whitePieces.get(i));
            dangerousBlocks.forEach(block -> dangerousBlocksForBlack.add(block));
            /*for (int j = 0; j < dangerousBlocks.size(); j++)
            {
                System.out.println(dangerousBlocks.get(j).getBlockDescription());
            }*/
            dangerousBlocks.clear();
            // setting this to true or false determines if dangerous squares are highlighted
            dangerousBlocksForBlack.forEach(block -> block.setDangerousButtonColor(true));
        }
    }
    
    
    private void findFakeDangerousBlocksForBlack()
    {
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        
        fakeDangerousBlocksForBlack.clear();
        for (int i = 0; i < whitePieces.size(); i++)
        {
            dangerousBlocks = findDangerousBlocks(whitePieces.get(i));
            dangerousBlocks.forEach(block -> dangerousBlocksForBlack.add(block));
            dangerousBlocks.clear();
        }
    }
    
    private ArrayList<ChessBlock> findDangerousBlocks(Piece piece)
    {
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        
        if ("pawn".equals(piece.pieceName))
        {
            if (piece.color == Color.WHITE)
            {
                if (piece.currentPosition.y + 1 < 8)
                {
                    if (piece.currentPosition.x - 1 >= 0)
                    {
                        if (!board[piece.currentPosition.x - 1][piece.currentPosition.y + 1].hasPiece() || board[piece.currentPosition.x - 1][piece.currentPosition.y + 1].hasPiece())
                        {
                            dangerousBlocks.add(board[piece.currentPosition.x - 1][piece.currentPosition.y + 1]);
                        }
                    }
                    
                    if (piece.currentPosition.x + 1 < 8)
                    {
                        if (!board[piece.currentPosition.x + 1][piece.currentPosition.y + 1].hasPiece() || board[piece.currentPosition.x + 1][piece.currentPosition.y + 1].hasPiece())
                        {
                            dangerousBlocks.add(board[piece.currentPosition.x + 1][piece.currentPosition.y + 1]);
                        }
                    } 
                }
            }
            else
            {
                if (piece.currentPosition.y - 1 >= 0)
                {
                    if (piece.currentPosition.x - 1 >= 0)
                    {
                        if (!board[piece.currentPosition.x - 1][piece.currentPosition.y - 1].hasPiece() || board[piece.currentPosition.x - 1][piece.currentPosition.y - 1].hasPiece())
                        {
                            dangerousBlocks.add(board[piece.currentPosition.x - 1][piece.currentPosition.y - 1]);
                        }
                    }
                    
                    if (piece.currentPosition.x + 1 < 8)
                    {
                        if (!board[piece.currentPosition.x + 1][piece.currentPosition.y - 1].hasPiece() || board[piece.currentPosition.x + 1][piece.currentPosition.y - 1].hasPiece())
                        {
                            dangerousBlocks.add(board[piece.currentPosition.x + 1][piece.currentPosition.y - 1]);
                        }
                    } 
                }
            }
            return dangerousBlocks;
        }
        else if ("rook".equals(piece.pieceName))
        {
            getRookDangerousMoves(piece.currentPosition);
            possibleMoves.forEach((block) -> { dangerousBlocks.add(block); });
            possibleCaptures.forEach((block) -> { dangerousBlocks.add(block); });
            possibleMoves.clear();
            possibleCaptures.clear();
            return dangerousBlocks;
        }
        else if ("knight".equals(piece.pieceName))
        {
            getKnightDangerousMoves(piece.currentPosition);
            possibleMoves.forEach((block) -> { dangerousBlocks.add(block); });
            possibleCaptures.forEach((block) -> { dangerousBlocks.add(block); });
            possibleMoves.clear();
            possibleCaptures.clear();
            return dangerousBlocks;
        }
        else if ("bishop".equals(piece.pieceName))
        {
            getBishopDangerousMoves(piece.currentPosition);
            possibleMoves.forEach((block) -> { dangerousBlocks.add(block); });
            possibleCaptures.forEach((block) -> { dangerousBlocks.add(block); });
            possibleMoves.clear();
            possibleCaptures.clear();
            return dangerousBlocks;
        }
        else if ("queen".equals(piece.pieceName))
        {
            getQueenDangerousMoves(piece.currentPosition);
            possibleMoves.forEach((block) -> { dangerousBlocks.add(block); });
            possibleCaptures.forEach((block) -> { dangerousBlocks.add(block); });
            possibleMoves.clear();
            possibleCaptures.clear();
            return dangerousBlocks;
        }
        else if ("king".equals(piece.pieceName))
        {
            getKingDangerousMoves(piece.currentPosition);
            possibleMoves.forEach((block) -> { dangerousBlocks.add(block); });
            possibleCaptures.forEach((block) -> { dangerousBlocks.add(block); });
            possibleMoves.clear();
            possibleCaptures.clear();
            return dangerousBlocks;
        }
        else
        {
            return dangerousBlocks;
        }
    }
    
    //This is to get the branch that put the king in check.
    
    private ArrayList<ChessBlock> checkDirection(Piece piece)
    {
        
        ArrayList<ChessBlock> dangerousBlocks = new ArrayList<>();
        ArrayList<ChessBlock> possibleBlocks = new ArrayList<>();
        
        if ("rook".equals(piece.pieceName) || "queen".equals(piece.pieceName))
        {
            upMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            downMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            leftMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            rightMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleMoves.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
        }            
        else if ("bishop".equals(piece.pieceName) || "queen".equals(piece.pieceName))
        {
            upLeftMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            downLeftMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            upRightMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleBlocks.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
            
            downRightMovesAndCaptures(piece.currentPosition);
            possibleMoves.forEach((block) -> dangerousBlocks.add(block));
            possibleCaptures.forEach((block) -> dangerousBlocks.add(block));
            for (int i = 0; i < dangerousBlocks.size(); i++)
            {
                if (dangerousBlocks.get(i).hasPiece() && dangerousBlocks.get(i).getPiece().pieceName == "king")
                {
                    possibleMoves.forEach((block) -> possibleBlocks.add(block));
                    possibleMoves.clear();
                    possibleCaptures.clear();
                    return possibleBlocks;
                }
            }
            possibleMoves.clear();
            possibleCaptures.clear();
            dangerousBlocks.clear();
        }            
        
        return dangerousBlocks;
    }
    
    private void clearPossibleMovesAndCaptures()
    {
        possibleMoves.forEach(block -> block.setPossibleMoveButtonColor(false));
        possibleMoves.clear();
        possibleCaptures.forEach(block -> block.setPossibleCaptureButtonColor(false));
        possibleCaptures.clear();
    }
    
    private void getPossibleMovesAndCaptures()
    {
        clearPossibleMovesAndCaptures();
        
        if ("pawn".equals(selectedBlock.getPiece().pieceName))
        {
            getPossiblePawnMovesAndCaptures(selectedBlock);
        }
        else if ("rook".equals(selectedBlock.getPiece().pieceName))
        {
            getPossibleRookMovesAndCaptures(selectedBlock);
        }
        else if ("knight".equals(selectedBlock.getPiece().pieceName))
        {
            getPossibleKnightMovesAndCaptures(selectedBlock);
        }
        else if ("bishop".equals(selectedBlock.getPiece().pieceName))
        {
            getPossibleBishopMovesAndCaptures(selectedBlock);
        }
        else if ("queen".equals(selectedBlock.getPiece().pieceName))
        {
            getPossibleQueenMovesAndCaptures(selectedBlock);
        }
        else if ("king".equals(selectedBlock.getPiece().pieceName))
        {
            getPossibleKingMovesAndCaptures(selectedBlock);
        }
      
        possibleMoves.forEach(block -> block.setPossibleMoveButtonColor(true));
        possibleCaptures.forEach(block -> block.setPossibleCaptureButtonColor(true));
    }
        
    private void getPossiblePawnMovesAndCaptures(ChessBlock block)
    {
        if (block.getPiece().color == Color.WHITE)
        {
            if (block.y + 1 < 8)
            {
                if (!board[block.x][block.y + 1].hasPiece())
                {
                    possibleMoves.add(board[block.x][block.y + 1]);
                    
                    if (!block.getPiece().hasMoved)
                    {
                        if (!board[block.x][block.y + 2].hasPiece())
                        {
                            possibleMoves.add(board[block.x][block.y + 2]);
                        }
                    }
                }
                
                if (block.x + 1 < 8)
                {
                    if (board[block.x + 1][block.y + 1].hasPiece())
                    {
                        if (board[block.x + 1][block.y + 1].getPiece().color != block.getPiece().color)
                        {
                            possibleCaptures.add(board[block.x + 1][block.y + 1]);
                        }
                    }
                }
                
                if (block.x - 1 >= 0)
                {
                    if (board[block.x - 1][block.y + 1].hasPiece())
                    {
                        if (board[block.x - 1][block.y + 1].getPiece().color != block.getPiece().color)
                        {
                            possibleCaptures.add(board[block.x - 1][block.y + 1]);
                        }
                    }
                }
                
                
                //enPassant capture logic
                //Needs a little work.
                for (int i = 0; i < 8; i++)
                {
                    if (board[i][4].hasPiece())
                    {
                        if (i == 0)
                        {
                            if (board[i][4].getPiece().pieceName == "pawn" && board[i][4].getPiece().color == Color.WHITE)
                            {
                                if(board[i+1][4].getPiece().pieceName =="pawn" && board[i+1][4].getPiece().color == Color.BLACK && board[i+1][4].getPiece().enPassantCounter == 1)
                                {
                                    possibleCaptures.add(board[i+1][5]);
                                }
                            }
                        }
                        else if (i != 0 && i != 7)
                        {
                            
                            if (board[i][4].getPiece().pieceName == "pawn" && board[i][4].getPiece().color == Color.WHITE)
                            {
                                
                                if(board[i+1][4].getPiece().pieceName =="pawn" && board[i+1][4].getPiece().color == Color.BLACK && board[i+1][4].getPiece().enPassantCounter == 1)
                                {
                                    possibleCaptures.add(board[i+1][5]);
                                }
                                else 
                                {
                                    if(board[i-1][4].getPiece().pieceName =="pawn" && board[i-1][4].getPiece().color == Color.BLACK && board[i-1][4].getPiece().enPassantCounter == 1)
                                    {
                                        possibleCaptures.add(board[i-1][5]);
                                    }
                                }
                                
                            }
                            
                        }
                        else
                        {
                            if(board[i-1][4].getPiece().pieceName =="pawn" && board[i-1][4].getPiece().color == Color.BLACK && board[i-1][4].getPiece().enPassantCounter == 1)
                            {
                                possibleCaptures.add(board[i-1][5]);
                            }
                        }
                    }
                }
            }
        }
        else
        {
            if (block.y - 1 > 0)
            {
                if (!board[block.x][block.y - 1].hasPiece())
                {
                    possibleMoves.add(board[block.x][block.y - 1]);
                    
                    if (!block.getPiece().hasMoved)
                    {
                        if (!board[block.x][block.y - 2].hasPiece())
                        {
                            possibleMoves.add(board[block.x][block.y - 2]);
                        }
                    }
                }
                
                if (block.x + 1 < 8)
                {
                    if (board[block.x + 1][block.y - 1].hasPiece())
                    {
                        if (board[block.x + 1][block.y - 1].getPiece().color != block.getPiece().color)
                        {
                            possibleCaptures.add(board[block.x + 1][block.y - 1]);
                        }
                    }
                }
                
                if (block.x - 1 >= 0)
                {
                    if (board[block.x - 1][block.y - 1].hasPiece())
                    {
                        if (board[block.x - 1][block.y - 1].getPiece().color != block.getPiece().color)
                        {
                            possibleCaptures.add(board[block.x - 1][block.y - 1]);
                        }
                    }
                }
                
                //enPassant capture logic
                for (int i = 0; i < 8; i++)
                {
                    if (board[i][3].hasPiece())
                    {
                        if (i == 0)
                        {
                            if (board[i][3].getPiece().pieceName == "pawn" && board[i][3].getPiece().color == Color.BLACK)
                            {
                                if(board[i+1][3].getPiece().pieceName =="pawn" && board[i+1][3].getPiece().color == Color.WHITE && board[i+1][3].getPiece().enPassantCounter == 1)
                                {
                                    possibleCaptures.add(board[i+1][2]);
                                }
                            }
                        }
                        else if (i != 0 && i != 7)
                        {
                            
                            if (board[i][3].getPiece().pieceName == "pawn" && board[i][3].getPiece().color == Color.BLACK)
                            {
                                
                                if(board[i+1][3].getPiece().pieceName =="pawn" && board[i+1][3].getPiece().color == Color.WHITE && board[i+1][3].getPiece().enPassantCounter == 1)
                                {
                                    possibleCaptures.add(board[i+1][2]);
                                }
                                else 
                                {
                                    if(board[i-1][3].getPiece().pieceName =="pawn" && board[i-1][3].getPiece().color == Color.WHITE && board[i-1][3].getPiece().enPassantCounter == 1)
                                    {
                                        possibleCaptures.add(board[i-1][2]);
                                    }
                                }
                                
                            }
                            
                        }
                        else
                        {
                            if(board[i-1][3].getPiece().pieceName =="pawn" && board[i-1][3].getPiece().color == Color.BLACK && board[i-1][3].getPiece().enPassantCounter == 1)
                            {
                                possibleCaptures.add(board[i-1][2]);
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void downMovesAndCaptures(ChessBlock block)
    {
       for (int x = block.x - 1; x >= 0; x--)
        {
            if (board[x][block.y].hasPiece())
            {
                if (board[x][block.y].getPiece().color != block.getPiece().color)
                {
                    possibleCaptures.add(board[x][block.y]);
                }
                break;
            }
            else
            {
                possibleMoves.add(board[x][block.y]);
            }
        }
    }
    
    private void rightMovesAndCaptures(ChessBlock block)
    {
       for (int y = block.y + 1; y < 8; y++)
        {
            if (board[block.x][y].hasPiece())
            {
                if (board[block.x][y].getPiece().color != block.getPiece().color)
                {
                    possibleCaptures.add(board[block.x][y]);
                }
                break;
            }
            else
            {
                possibleMoves.add(board[block.x][y]);
            }
        }
    }
    
    private void leftMovesAndCaptures(ChessBlock block)
    {
       for (int y = block.y - 1; y >= 0; y--)
        {
            if (board[block.x][y].hasPiece())
            {
                if (board[block.x][y].getPiece().color != block.getPiece().color)
                {
                    possibleCaptures.add(board[block.x][y]);
                }
                break;
            }
            else
            {
                possibleMoves.add(board[block.x][y]);
            }
        }
    }
    
    private void upMovesAndCaptures(ChessBlock block)
    {
       for (int x = block.x + 1; x < 8; x++)
        {
            if (board[x][block.y].hasPiece())
            {
                if (board[x][block.y].getPiece().color != block.getPiece().color)
                {
                    possibleCaptures.add(board[x][block.y]);
                }
                break;
            }
            else
            {
                possibleMoves.add(board[x][block.y]);
            }
        }
    }
    
    private void downRightMovesAndCaptures(ChessBlock block)
    {
       for (int i = 1; i < 8; i++)
        {
            if (block.x + i > 7 || block.y - i < 0)
            {
                break;
            }
            else
            {
                if (board[block.x + i][block.y - i].hasPiece())
                {
                    if (board[block.x + i][block.y - i].getPiece().color != block.getPiece().color)
                    {
                        possibleCaptures.add(board[block.x + i][block.y - i]);
                    }
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x + i][block.y - i]);
                }
            }
        }
    }
    
    private void downLeftMovesAndCaptures(ChessBlock block)
    {
       for (int i = 1; i < 8; i++)
        {
            if (block.x - i < 0 || block.y - i < 0)
            {
                break;
            }
            else
            {
                if (board[block.x - i][block.y - i].hasPiece())
                {
                    if (board[block.x - i][block.y - i].getPiece().color != block.getPiece().color)
                    {
                        possibleCaptures.add(board[block.x - i][block.y - i]);
                    }
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x - i][block.y - i]);
                }
            }
        }
    }
    
    private void upLeftMovesAndCaptures(ChessBlock block)
    {
       for (int i = 1; i < 8; i++)
        {
            if (block.x - i < 0 || block.y + i > 7)
            {
                break;
            }
            else
            {
                if (board[block.x - i][block.y + i].hasPiece())
                {
                    if (board[block.x - i][block.y + i].getPiece().color != block.getPiece().color)
                    {
                        possibleCaptures.add(board[block.x - i][block.y + i]);
                    }
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x - i][block.y + i]);
                }
            }
        }
    }
    
    private void upRightMovesAndCaptures(ChessBlock block)
    {
       for (int i = 1; i < 8; i++)
        {
            if (block.x + i > 7 || block.y + i > 7)
            {
                break;
            }
            else
            {
                if (board[block.x + i][block.y + i].hasPiece())
                {
                    if (board[block.x + i][block.y + i].getPiece().color != block.getPiece().color)
                    {
                        possibleCaptures.add(board[block.x + i][block.y + i]);
                    }
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x + i][block.y + i]);
                }
            }
        }
    }
    
    private void getPossibleRookMovesAndCaptures(ChessBlock block)
    {  
        rightMovesAndCaptures(block);
        
        leftMovesAndCaptures(block);
        
        upMovesAndCaptures(block);
        
        downMovesAndCaptures(block);
    }
    
    private void getRookDangerousMoves(ChessBlock block)
    {
        for (int y = block.y + 1; y < 8; y++)
        {
            if (board[block.x][y].hasPiece())
            {
                possibleCaptures.add(board[block.x][y]);
                break;
            }
            else
            {
                possibleMoves.add(board[block.x][y]);
            }
        }

        for (int y = block.y - 1; y >= 0; y--)
        {
            if (board[block.x][y].hasPiece())
            {
                possibleCaptures.add(board[block.x][y]);
                break;
            }
            else
            {
                possibleMoves.add(board[block.x][y]);
            }
        }

        for (int x = block.x + 1; x < 8; x++)
        {
            if (board[x][block.y].hasPiece())
            {
                possibleCaptures.add(board[x][block.y]);
                break;
            }
            else
            {
                possibleMoves.add(board[x][block.y]);
            }
        }

        for (int x = block.x - 1; x >= 0; x--)
        {
            if (board[x][block.y].hasPiece())
            {
                possibleCaptures.add(board[x][block.y]);
                break;
            }
            else
            {
                possibleMoves.add(board[x][block.y]);
            }
        }
    }
    
    private void getPossibleKnightMovesAndCaptures(ChessBlock block)
    {
        int[] x = { block.x - 2, block.x - 2, block.x + 2, block.x + 2,
                    block.x - 1, block.x + 1, block.x - 1, block.x + 1 };
        int[] y = { block.y - 1, block.y + 1, block.y - 1, block.y + 1,
                    block.y - 2, block.y - 2, block.y + 2, block.y + 2 };

        for (int i = 0; i < 8; i++)
        {
            if (x[i] >= 0 && x[i] < 8 && y[i] >= 0 && y[i] < 8)
            {
                if (!board[x[i]][y[i]].hasPiece())
                {
                    possibleMoves.add(board[x[i]][y[i]]);
                }
                else if (board[x[i]][y[i]].getPiece().color != block.getPiece().color)
                {
                    possibleCaptures.add(board[x[i]][y[i]]);
                }
            }
        }
    }
    
    private void getKnightDangerousMoves(ChessBlock block)
    {
        int[] x = { block.x - 2, block.x - 2, block.x + 2, block.x + 2,
                    block.x - 1, block.x + 1, block.x - 1, block.x + 1 };
        int[] y = { block.y - 1, block.y + 1, block.y - 1, block.y + 1,
                block.y - 2, block.y - 2, block.y + 2, block.y + 2 };

        for (int i = 0; i < 8; i++)
        {
            if (x[i] >= 0 && x[i] < 8 && y[i] >= 0 && y[i] < 8)
            {
                possibleMoves.add(board[x[i]][y[i]]);
            }
        }
    }
    
    private void getPossibleBishopMovesAndCaptures(ChessBlock block)
    {
        upRightMovesAndCaptures(block);
        
        upLeftMovesAndCaptures(block);
        
        downLeftMovesAndCaptures(block);
        
        downRightMovesAndCaptures(block);
    }
    
    private void getBishopDangerousMoves(ChessBlock block)
    {
        for (int i = 1; i < 8; i++)
        {
            if (block.x + i > 7 || block.y + i > 7)
            {
                break;
            }
            else
            {
                if (board[block.x + i][block.y + i].hasPiece())
                {
                    possibleCaptures.add(board[block.x + i][block.y + i]);
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x + i][block.y + i]);
                }
            }
        }
        
        for (int i = 1; i < 8; i++)
        {
            if (block.x - i < 0 || block.y + i > 7)
            {
                break;
            }
            else
            {
                if (board[block.x - i][block.y + i].hasPiece())
                {
                    possibleCaptures.add(board[block.x - i][block.y + i]);
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x - i][block.y + i]);
                }
            }
        }
        
        for (int i = 1; i < 8; i++)
        {
            if (block.x - i < 0 || block.y - i < 0)
            {
                break;
            }
            else
            {
                if (board[block.x - i][block.y - i].hasPiece())
                {
                    possibleCaptures.add(board[block.x - i][block.y - i]);
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x - i][block.y - i]);
                }
            }
        }
        
        for (int i = 1; i < 8; i++)
        {
            if (block.x + i > 7 || block.y - i < 0)
            {
                break;
            }
            else
            {
                if (board[block.x + i][block.y - i].hasPiece())
                {
                    possibleCaptures.add(board[block.x + i][block.y - i]);
                    break;
                }
                else
                {
                    possibleMoves.add(board[block.x + i][block.y - i]);
                }
            }
        }
    }            
    
    private void getPossibleQueenMovesAndCaptures(ChessBlock block)
    {
        getPossibleRookMovesAndCaptures(block);
        getPossibleBishopMovesAndCaptures(block);
    }
    
    private void getQueenDangerousMoves(ChessBlock block)
    {
        getRookDangerousMoves(block);
        getBishopDangerousMoves(block);
    }
    
    private void getPossibleKingMovesAndCaptures(ChessBlock block)
    {
        int[][] xy = { {block.x     ,    block.y + 1 },
                       {block.x + 1 ,    block.y + 1 },
                       {block.x + 1 ,    block.y     },
                       {block.x + 1 ,    block.y - 1 },
                       {block.x     ,    block.y - 1 },
                       {block.x - 1 ,    block.y - 1 },
                       {block.x - 1 ,    block.y     },
                       {block.x - 1 ,    block.y + 1 },
                       {block.x - 3 ,    block.y     },
                       {block.x + 2 ,    block.y     },
                       {block.x - 2 ,    block.y     } };
        
        if (block.getPiece().color == Color.WHITE)
        {
            if (!block.getPiece().hasMoved && !board[7][0].getPiece().hasMoved)
            {
                if (!dangerousBlocksForWhite.contains(block.getPiece().currentPosition))
                {
                    if (!dangerousBlocksForWhite.contains(board[5][0]) && !dangerousBlocksForWhite.contains(board[6][0]))
                    {
                        if (!board[5][0].hasPiece() && !board[6][0].hasPiece())
                        {
                            possibleMoves.add(board[6][0]);
                        }
                    }
                }
            }
            
            //This doesn't work for some reason while the previos one does.
            
            else if (!block.getPiece().hasMoved && !board[0][0].getPiece().hasMoved)
            {
                if (!dangerousBlocksForWhite.contains(block.getPiece().currentPosition))
                {
                    if (!dangerousBlocksForWhite.contains(board[3][0]) && !dangerousBlocksForWhite.contains(board[2][0]))
                    {
                        if (!board[3][0].hasPiece() && !board[2][0].hasPiece() && !board[1][0].hasPiece())
                        {
                            possibleMoves.add(board[2][0]);
                        }
                    }
                }
            }
        }
        else
        {
            if (!block.getPiece().hasMoved && board[7][7].getPiece().hasMoved)
            {
                if (!dangerousBlocksForBlack.contains(block.getPiece().currentPosition))
                {
                    if (!dangerousBlocksForBlack.contains(board[5][7]) && !dangerousBlocksForBlack.contains(board[6][7]))
                    {
                        if (!board[5][0].hasPiece() && !board[6][7].hasPiece())
                        {
                            possibleMoves.add(board[6][7]);
                        }
                    }
                }
            }
            else if (!block.getPiece().hasMoved && board[0][7].getPiece().hasMoved)
            {
                if (!dangerousBlocksForBlack.contains(block.getPiece().currentPosition))
                {
                    if (!dangerousBlocksForBlack.contains(board[3][7]) && !dangerousBlocksForBlack.contains(board[2][7]))
                    {
                        if (!board[3][0].hasPiece() && !board[2][7].hasPiece() && !board[1][7].hasPiece())
                        {
                            possibleMoves.add(board[2][7]);
                        }
                    }
                }
            }
        }
        
        for (int i = 0; i < 8; i++)
        {
            if (xy[i][0] >= 0 && xy[i][0] < 8 && xy[i][1] >= 0 && xy[i][1] < 8)
            {
                if (!board[xy[i][0]][xy[i][1]].hasPiece())
                {
                    if (block.getPiece().color == Color.WHITE)
                    {
                        if (!dangerousBlocksForWhite.contains(board[xy[i][0]][xy[i][1]]))
                        {
                            possibleMoves.add(board[xy[i][0]][xy[i][1]]);
                        }
                    }
                    else
                    {
                        if (!dangerousBlocksForBlack.contains(board[xy[i][0]][xy[i][1]]))
                        {
                            possibleMoves.add(board[xy[i][0]][xy[i][1]]);
                        }
                    }
                }
                else if (board[xy[i][0]][xy[i][1]].getPiece().color != block.getPiece().color)
                {
                    if (block.getPiece().color == Color.WHITE)
                    {
                        if (!dangerousBlocksForWhite.contains(board[xy[i][0]][xy[i][1]]))
                        {
                            possibleCaptures.add(board[xy[i][0]][xy[i][1]]);
                        }
                    }
                    else
                    {
                        if (!dangerousBlocksForBlack.contains(board[xy[i][0]][xy[i][1]]))
                        {
                            possibleCaptures.add(board[xy[i][0]][xy[i][1]]);
                        }
                    }
                }
            }
        }
    }
    
    private void getKingDangerousMoves(ChessBlock block)
    {
        int[][] xy = { {block.x, block.y + 1},
                       {block.x + 1, block.y + 1},
                       {block.x + 1, block.y},
                       {block.x + 1, block.y - 1},
                       {block.x, block.y - 1},
                       {block.x - 1, block.y - 1},
                       {block.x - 1, block.y},
                       {block.x - 1, block.y + 1} };
        
        for (int i = 0; i < 8; i++)
        {
            if (xy[i][0] >= 0 && xy[i][0] < 8 && xy[i][1] >= 0 && xy[i][1] < 8)
            {
                if (block.getPiece().color == Color.WHITE)
                {
                    if (!dangerousBlocksForWhite.contains(board[xy[i][0]][xy[i][1]]))
                    {
                        possibleMoves.add(board[xy[i][0]][xy[i][1]]);
                    }
                }
                else
                {
                    if (!dangerousBlocksForBlack.contains(board[xy[i][0]][xy[i][1]]))
                    {
                        possibleMoves.add(board[xy[i][0]][xy[i][1]]);
                    }
                }
            }
        }
    }
    
    public class MovePieceListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if (player == 1){
                if("00".equals(e.getActionCommand())){
                    blockClicked(board[0][0]);
                }else if("01".equals(e.getActionCommand())){
                    blockClicked(board[1][0]);
                }else if("02".equals(e.getActionCommand())){
                    blockClicked(board[2][0]);
                }else if("03".equals(e.getActionCommand())){
                    blockClicked(board[3][0]);
                }else if("04".equals(e.getActionCommand())){
                    blockClicked(board[4][0]);
                }else if("05".equals(e.getActionCommand())){
                    blockClicked(board[5][0]);
                }else if("06".equals(e.getActionCommand())){
                    blockClicked(board[6][0]);
                }else if("07".equals(e.getActionCommand())){
                    blockClicked(board[7][0]);
                }else if("10".equals(e.getActionCommand())){
                    blockClicked(board[0][1]);
                }else if("11".equals(e.getActionCommand())){
                    blockClicked(board[1][1]);
                }else if("12".equals(e.getActionCommand())){
                    blockClicked(board[2][1]);
                }else if("13".equals(e.getActionCommand())){
                    blockClicked(board[3][1]);
                }else if("14".equals(e.getActionCommand())){
                    blockClicked(board[4][1]);
                }else if("15".equals(e.getActionCommand())){
                    blockClicked(board[5][1]);
                }else if("16".equals(e.getActionCommand())){
                    blockClicked(board[6][1]);
                }else if("17".equals(e.getActionCommand())){
                    blockClicked(board[7][1]);
                }else if("20".equals(e.getActionCommand())){
                    blockClicked(board[0][2]);
                }else if("21".equals(e.getActionCommand())){
                    blockClicked(board[1][2]);
                }else if("22".equals(e.getActionCommand())){
                    blockClicked(board[2][2]);
                }else if("23".equals(e.getActionCommand())){
                    blockClicked(board[3][2]);
                }else if("24".equals(e.getActionCommand())){
                    blockClicked(board[4][2]);
                }else if("25".equals(e.getActionCommand())){
                    blockClicked(board[5][2]);
                }else if("26".equals(e.getActionCommand())){
                    blockClicked(board[6][2]);
                }else if("27".equals(e.getActionCommand())){
                    blockClicked(board[7][2]);
                }else if("30".equals(e.getActionCommand())){
                    blockClicked(board[0][3]);
                }else if("31".equals(e.getActionCommand())){
                    blockClicked(board[1][3]);
                }else if("32".equals(e.getActionCommand())){
                    blockClicked(board[2][3]);
                }else if("33".equals(e.getActionCommand())){
                    blockClicked(board[3][3]);
                }else if("34".equals(e.getActionCommand())){
                    blockClicked(board[4][3]);
                }else if("35".equals(e.getActionCommand())){
                    blockClicked(board[5][3]);
                }else if("36".equals(e.getActionCommand())){
                    blockClicked(board[6][3]);
                }else if("37".equals(e.getActionCommand())){
                    blockClicked(board[7][3]);
                }else if("40".equals(e.getActionCommand())){
                    blockClicked(board[0][4]);
                }else if("41".equals(e.getActionCommand())){
                    blockClicked(board[1][4]);
                }else if("42".equals(e.getActionCommand())){
                    blockClicked(board[2][4]);
                }else if("43".equals(e.getActionCommand())){
                    blockClicked(board[3][4]);
                }else if("44".equals(e.getActionCommand())){
                    blockClicked(board[4][4]);
                }else if("45".equals(e.getActionCommand())){
                    blockClicked(board[5][4]);
                }else if("46".equals(e.getActionCommand())){
                    blockClicked(board[6][4]);
                }else if("47".equals(e.getActionCommand())){
                    blockClicked(board[7][4]);
                }else if("50".equals(e.getActionCommand())){
                    blockClicked(board[0][5]);
                }else if("51".equals(e.getActionCommand())){
                    blockClicked(board[1][5]);
                }else if("52".equals(e.getActionCommand())){
                    blockClicked(board[2][5]);
                }else if("53".equals(e.getActionCommand())){
                    blockClicked(board[3][5]);
                }else if("54".equals(e.getActionCommand())){
                    blockClicked(board[4][5]);
                }else if("55".equals(e.getActionCommand())){
                    blockClicked(board[5][5]);
                }else if("56".equals(e.getActionCommand())){
                    blockClicked(board[6][5]);
                }else if("57".equals(e.getActionCommand())){
                    blockClicked(board[7][5]);
                }else if("60".equals(e.getActionCommand())){
                    blockClicked(board[0][6]);
                }else if("61".equals(e.getActionCommand())){
                    blockClicked(board[1][6]);
                }else if("62".equals(e.getActionCommand())){
                    blockClicked(board[2][6]);
                }else if("63".equals(e.getActionCommand())){
                    blockClicked(board[3][6]);
                }else if("64".equals(e.getActionCommand())){
                    blockClicked(board[4][6]);
                }else if("65".equals(e.getActionCommand())){
                    blockClicked(board[5][6]);
                }else if("66".equals(e.getActionCommand())){
                    blockClicked(board[6][6]);
                }else if("67".equals(e.getActionCommand())){
                    blockClicked(board[7][6]);
                }else if("70".equals(e.getActionCommand())){
                    blockClicked(board[0][7]);
                }else if("71".equals(e.getActionCommand())){
                    blockClicked(board[1][7]);
                }else if("72".equals(e.getActionCommand())){
                    blockClicked(board[2][7]);
                }else if("73".equals(e.getActionCommand())){
                    blockClicked(board[3][7]);
                }else if("74".equals(e.getActionCommand())){
                    blockClicked(board[4][7]);
                }else if("75".equals(e.getActionCommand())){
                    blockClicked(board[5][7]);
                }else if("76".equals(e.getActionCommand())){
                    blockClicked(board[6][7]);
                }else if("77".equals(e.getActionCommand())){
                    blockClicked(board[7][7]);
                }
            }else if (player == 2){
                
                if("77".equals(e.getActionCommand())){
                    blockClicked(board[0][0]);
                }else if("76".equals(e.getActionCommand())){
                    blockClicked(board[1][0]);
                }else if("75".equals(e.getActionCommand())){
                    blockClicked(board[2][0]);
                }else if("74".equals(e.getActionCommand())){
                    blockClicked(board[3][0]);
                }else if("73".equals(e.getActionCommand())){
                    blockClicked(board[4][0]);
                }else if("72".equals(e.getActionCommand())){
                    blockClicked(board[5][0]);
                }else if("71".equals(e.getActionCommand())){
                    blockClicked(board[6][0]);
                }else if("70".equals(e.getActionCommand())){
                    blockClicked(board[7][0]);
                }else if("67".equals(e.getActionCommand())){
                    blockClicked(board[0][1]);
                }else if("66".equals(e.getActionCommand())){
                    blockClicked(board[1][1]);
                }else if("65".equals(e.getActionCommand())){
                    blockClicked(board[2][1]);
                }else if("64".equals(e.getActionCommand())){
                    blockClicked(board[3][1]);
                }else if("63".equals(e.getActionCommand())){
                    blockClicked(board[4][1]);
                }else if("62".equals(e.getActionCommand())){
                    blockClicked(board[5][1]);
                }else if("61".equals(e.getActionCommand())){
                    blockClicked(board[6][1]);
                }else if("60".equals(e.getActionCommand())){
                    blockClicked(board[7][1]);
                }else if("57".equals(e.getActionCommand())){
                    blockClicked(board[0][2]);
                }else if("56".equals(e.getActionCommand())){
                    blockClicked(board[1][2]);
                }else if("55".equals(e.getActionCommand())){
                    blockClicked(board[2][2]);
                }else if("54".equals(e.getActionCommand())){
                    blockClicked(board[3][2]);
                }else if("53".equals(e.getActionCommand())){
                    blockClicked(board[4][2]);
                }else if("52".equals(e.getActionCommand())){
                    blockClicked(board[5][2]);
                }else if("51".equals(e.getActionCommand())){
                    blockClicked(board[6][2]);
                }else if("50".equals(e.getActionCommand())){
                    blockClicked(board[7][2]);
                }else if("47".equals(e.getActionCommand())){
                    blockClicked(board[0][3]);
                }else if("46".equals(e.getActionCommand())){
                    blockClicked(board[1][3]);
                }else if("45".equals(e.getActionCommand())){
                    blockClicked(board[2][3]);
                }else if("44".equals(e.getActionCommand())){
                    blockClicked(board[3][3]);
                }else if("43".equals(e.getActionCommand())){
                    blockClicked(board[4][3]);
                }else if("42".equals(e.getActionCommand())){
                    blockClicked(board[5][3]);
                }else if("41".equals(e.getActionCommand())){
                    blockClicked(board[6][3]);
                }else if("40".equals(e.getActionCommand())){
                    blockClicked(board[7][3]);
                }else if("37".equals(e.getActionCommand())){
                    blockClicked(board[0][4]);
                }else if("36".equals(e.getActionCommand())){
                    blockClicked(board[1][4]);
                }else if("35".equals(e.getActionCommand())){
                    blockClicked(board[2][4]);
                }else if("34".equals(e.getActionCommand())){
                    blockClicked(board[3][4]);
                }else if("33".equals(e.getActionCommand())){
                    blockClicked(board[4][4]);
                }else if("32".equals(e.getActionCommand())){
                    blockClicked(board[5][4]);
                }else if("31".equals(e.getActionCommand())){
                    blockClicked(board[6][4]);
                }else if("30".equals(e.getActionCommand())){
                    blockClicked(board[7][4]);
                }else if("27".equals(e.getActionCommand())){
                    blockClicked(board[0][5]);
                }else if("26".equals(e.getActionCommand())){
                    blockClicked(board[1][5]);
                }else if("25".equals(e.getActionCommand())){
                    blockClicked(board[2][5]);
                }else if("24".equals(e.getActionCommand())){
                    blockClicked(board[3][5]);
                }else if("23".equals(e.getActionCommand())){
                    blockClicked(board[4][5]);
                }else if("22".equals(e.getActionCommand())){
                    blockClicked(board[5][5]);
                }else if("21".equals(e.getActionCommand())){
                    blockClicked(board[6][5]);
                }else if("20".equals(e.getActionCommand())){
                    blockClicked(board[7][5]);
                }else if("17".equals(e.getActionCommand())){
                    blockClicked(board[0][6]);
                }else if("16".equals(e.getActionCommand())){
                    blockClicked(board[1][6]);
                }else if("15".equals(e.getActionCommand())){
                    blockClicked(board[2][6]);
                }else if("14".equals(e.getActionCommand())){
                    blockClicked(board[3][6]);
                }else if("13".equals(e.getActionCommand())){
                    blockClicked(board[4][6]);
                }else if("12".equals(e.getActionCommand())){
                    blockClicked(board[5][6]);
                }else if("11".equals(e.getActionCommand())){
                    blockClicked(board[6][6]);
                }else if("10".equals(e.getActionCommand())){
                    blockClicked(board[7][6]);
                }else if("07".equals(e.getActionCommand())){
                    blockClicked(board[0][7]);
                }else if("06".equals(e.getActionCommand())){
                    blockClicked(board[1][7]);
                }else if("05".equals(e.getActionCommand())){
                    blockClicked(board[2][7]);
                }else if("04".equals(e.getActionCommand())){
                    blockClicked(board[3][7]);
                }else if("03".equals(e.getActionCommand())){
                    blockClicked(board[4][7]);
                }else if("02".equals(e.getActionCommand())){
                    blockClicked(board[5][7]);
                }else if("01".equals(e.getActionCommand())){
                    blockClicked(board[6][7]);
                }else if("00".equals(e.getActionCommand())){
                    blockClicked(board[7][7]);
                }
            }
        }
    }
}