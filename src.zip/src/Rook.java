
import java.awt.Color;
import javax.swing.ImageIcon;

public class Rook extends Piece implements PiecesInterface 
{    
    public Rook(Color color, ChessBlock startingPosition, boolean putInCheck)
    {
        super(color, startingPosition, putInCheck);
        pieceName = "rook";
    }
    
    public void castle()
    {
        //move the king left 3 squares and rook right 2 squares or move king right
        //2 squares and rook left 2 squares (essentially swapping position of king and rook
        // -can't happen through a threatened square
        // -castle can only happen if the king and rook have not moved
    }
    
    @Override
    public ImageIcon getPieceIcon() 
    {
        if (color == Color.WHITE)
        {
            return new ImageIcon("White_Rook.png");
        }
        else
        {
            return new ImageIcon("Black_Rook.png");
        }
    }
}
