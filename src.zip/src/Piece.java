
import java.awt.Color;
import javax.swing.ImageIcon;

public class Piece
{
    protected final Color color;
    protected ChessBlock currentPosition;
    protected final ChessBlock startingPosition;
    protected String pieceName;
    protected boolean hasMoved = false;
    protected boolean putInCheck;
    protected int enPassantCounter;
    protected boolean isPawn;
    
    public Piece(Color color, ChessBlock startingPosition, boolean putInCheck)
    {
         this.color = color;
         this.startingPosition = startingPosition;
         currentPosition = startingPosition;
         this.putInCheck = putInCheck;
         if (isPawn)
         {
             enPassantCounter = 1;
         }
    }
    
    public void move(ChessBlock position)
    {
        position.setPiece(currentPosition.getPiece());
        currentPosition.setPiece(null);
        currentPosition = position;
        hasMoved = true;
    }
    
    public void fakeMove(ChessBlock position)
    {
        position.setPiece(currentPosition.getPiece());
        currentPosition.setPiece(null);
        currentPosition = position;
    }
    
    public void revert(ChessBlock previous)
    {
        previous.setPiece(currentPosition.getPiece());
        currentPosition.setPiece(null);
        currentPosition = previous;
    }
    
    public void switchPutInCheck()
    {
        if (putInCheck == true)
        {
            putInCheck = false;
        }
        else
        {
            putInCheck = true;
        }
    }
    
    public void decreaseEnPassantCounter()
    {
        enPassantCounter = 0;
    }
    
    public ImageIcon getPieceIcon()
    {
        return new ImageIcon();
    }
    
    public Color getPieceColor()
    {
        return color;
    }
    
    public ChessBlock getCurrentPosition()
    {
        return currentPosition;
    }
    
    public ChessBlock getStartingPosition()
    {
        return startingPosition;
    }
    
    public boolean isPieceInStartingPosition()
    {
        return currentPosition == startingPosition;
    }
    
    public void setCurrentPosition(ChessBlock position)
    {
        currentPosition = position;
    }
    
    public String getPieceDescription()
    {
        if (color == Color.BLACK)
        {
            return "Black" + pieceName;
        }
        else
        {
            return "White" + pieceName;
        }
    }
}