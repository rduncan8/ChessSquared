

public class PlayerWhite 
{    
    private static final int player = 1;
    
    public PlayerWhite() 
    {
        ChessBoard chess = new ChessBoard(player);
    }
}
