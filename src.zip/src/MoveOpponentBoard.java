
public class MoveOpponentBoard 
{
    
    /*ChessBoard
        if player 1
            if move piece
                update player 2 chessboard via switching +/-
            if capture piece
                update player 2 chessboard via switching +/-
    */
    
}
