

public class PlayerBlack 
{    
    private static final int player = 2;
    
    public PlayerBlack() 
    {
        ChessBoard chess = new ChessBoard(player);
    }
    
}
